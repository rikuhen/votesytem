<template>
  <div class="pcoded-content">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "ContentComponent"
};
</script>

<style>
</style>
