<?php echo e($slot); ?>

<?php /**PATH /var/www/php73/votaciones/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>